PolyLoot preview sample: 3d-road-tiles
One model from the Kenney pack: Models/roadTile_001.obj
License: CC0 1.0. Source: https://kenney.nl/assets
This is a small preview only. Other textures, animations, and models are in the full pack.
PolyLoot prices and checkout are simulated; Kenney offers the original assets for free.
