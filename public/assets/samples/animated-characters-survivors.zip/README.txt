PolyLoot preview sample: animated-characters-survivors
One model from the Kenney pack: Model/characterMedium.fbx
License: CC0 1.0. Source: https://kenney.nl/assets
This is a small preview only. Other textures, animations, and models are in the full pack.
PolyLoot prices and checkout are simulated; Kenney offers the original assets for free.
