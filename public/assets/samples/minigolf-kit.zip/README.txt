PolyLoot preview sample: minigolf-kit
One model from the Kenney pack: Models/GLB format/ball-blue.glb
License: CC0 1.0. Source: https://kenney.nl/assets
This is a small preview only. Other textures, animations, and models are in the full pack.
PolyLoot prices and checkout are simulated; Kenney offers the original assets for free.
